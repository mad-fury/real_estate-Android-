package com.example.util;

public interface OnClick {

    void position(int position);

}
