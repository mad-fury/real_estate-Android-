package com.example.util;

public interface FavouriteIF {

    void isFavourite(String isFavourite, String message);

}
